# Fynova
Fynova mainly refers to micro-credit. A micro credit corresponds to a loan of a small amount intended primarily for people with little or no income.
