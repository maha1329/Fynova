package tn.fynova.spring.service;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.annotation.JsonIgnore;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.repository.UserRepository;
import tn.fynova.spring.entities.UserPrinciple;

@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	UserRepository userRepository;
	
	@Override
	public User addUser(User e) {
		User user = userRepository.save(e);
		return user;
	}
	
	@Override
	public void deleteUser(int id) {
		userRepository.deleteById(id);
		
	}

	@Override
	public List<User> retrieveAllUsers() {
		List<User> users = (List<User>) userRepository.findAll();
		return users;
	}
   /* @Override
	public User authenticate (String login, String password)
	{return userRepository.getUserByEmailAndPassword(login, password);
	}*/
	@Override
	public Optional<User> retrieveUser(int id) {
		Optional<User> user = userRepository.findById(id);
		return user;
	}

	/*@Override
	public long totcountByRole(Role type) {
		
		return userRepository.countByRole(type);
	}*/


	}
	

