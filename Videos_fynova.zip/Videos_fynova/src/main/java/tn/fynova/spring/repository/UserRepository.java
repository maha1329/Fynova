package tn.fynova.spring.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
    Optional<User> findByUsername(String username);
   
	public User findUserByUsername(String email);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
   // @Query("SELECT COUNT(*) FROM User u WHERE u.userrole= :role " )
    //@Query(value = "SELECT COUNT(*) FROM User u WHERE u.Role= :role " , nativeQuery =
    	//	true)
	//long countByRole(@Param("userrole")Role userrole);
    @Query("SELECT COUNT(u) FROM User u " )
	float nbUtilisateur();
    @Query("SELECT COUNT(u) FROM User u WHERE u.userrole LIKE 'Customer' " )
	float nbclient(@Param("userrole")Role customer);
  
	
    @Query("SELECT COUNT(u) FROM User u WHERE u.userrole LIKE 'Employee' " )
	float nbemployee(@Param("userrole")Role employee);
    @Query("SELECT COUNT(u) FROM User u WHERE u.userrole LIKE 'Investor' " )
	float nbinvestisseur(@Param("userrole")Role investor);
    
   @Query("SELECT COUNT(u) FROM User u WHERE u.userrole LIKE 'Association' " )
	float nbassociation(@Param("userrole")Role association);
    
    //statistique par job
   @Query("SELECT COUNT(u) FROM User u WHERE u.job =':etudiant' " )
   float nbetudiant(String string);
   @Query("SELECT COUNT(u) FROM User u WHERE u.job =':publicjob' " )
	float nbjobpublic(String string);
   @Query("SELECT COUNT(u) FROM User u WHERE u.job = ':privatejob' " )
	float nbjobprive(String string);
   @Query("SELECT COUNT(u) FROM User u WHERE u.job = ':retraite' " )
	float nbretraite(String string);
    //Classification d'age
    
  
    
    @Query("SELECT u.userbirthday FROM User u WHERE u.username=:username ")
    Date GetGoodAge(@Param("username") String username);
    
   
	


    
//Classification par job
	
    @Query("SELECT u.job FROM User u WHERE u.username=:username")
    String GetclassProfession(@Param("username") String username);
    
    

   @Query("SELECT u.assurance_vie FROM User u WHERE u.username=:username")
    Boolean GetclassAssurance(@Param("username") String username);
   @Query("SELECT u.userrole FROM User u WHERE u.username=:username")  
Role findRoleByUsername(@Param("username")String username);

   
//User getUserByEmailAndPassword(String login, String password);

   @Query("SELECT u FROM User u WHERE u.userrole LIKE 'Customer' " )
  	List<User> Userclient();
    
  	
      @Query("SELECT u FROM User u WHERE u.userrole LIKE 'Employee' " )
      List<User> Useremployee();
      @Query("SELECT u FROM User u WHERE u.userrole LIKE 'Investor' " )
      List<User> Userinvestisseur();
      
     @Query("SELECT u FROM User u WHERE u.userrole LIKE 'Association' " )
     List<User> Userassociation();

   
}
