package tn.fynova.spring.authentification.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.security.RolesAllowed;
import javax.faces.application.FacesMessage;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.mapstruct.Named;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.primefaces.event.ItemSelectEvent;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.pie.PieChartDataSet;
import org.primefaces.model.charts.pie.PieChartModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.repository.UserRepository;
import tn.fynova.spring.service.ClassificationUser;
import tn.fynova.spring.service.UserDetailsServiceImpl;

@Scope(value = "session")
@Controller(value = "StatController") // Name of the bean in Spring IoC
@ELBeanName(value = "StatController") 
@RolesAllowed("Employee")
//@RestController
public class StatUserController implements Serializable{
	
    @Autowired
    private  UserRepository userRepository;
    @Autowired
    private ClassificationUser su;
    //@Autowired
   // private UserDetailsServiceImpl su;
 
	public StatUserController(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
  /* // @GetMapping("/StatRole")
    public long getAllUsers(@PathVariable("userrole")  Role role){
        return userRepository.countByRole(role);
    }*/
	
	private PieChartModel pieModel;
	private PieChartModel pieModel1;
	 @PostConstruct
	    public void init() {
	        createPieModel();
	        createPieModel1();}
	 @RolesAllowed("Employee")
	 private void createPieModel() {
	        pieModel = new PieChartModel();
	        ChartData data = new ChartData();

	        PieChartDataSet dataSet = new PieChartDataSet();
	        List<Number> values = new ArrayList<>();
	        values.add(userRepository.nbclient(Role.Customer));
	        values.add(userRepository.nbinvestisseur(Role.Investor));
	        values.add(userRepository.nbassociation(Role.Association));
	        values.add(userRepository.nbemployee(Role.Employee));
	        dataSet.setData(values);

	        List<String> bgColors = new ArrayList<>();
	        bgColors.add("rgb(255, 99, 132)");
	        bgColors.add("rgb(54, 162, 235)");
	        bgColors.add("rgb(255, 205, 86)");
	        bgColors.add("rgb(201, 203, 207)");
	        dataSet.setBackgroundColor(bgColors);

	        data.addChartDataSet(dataSet);
	        List<String> labels = new ArrayList<>();
	        labels.add("Customer");
	        labels.add("Investor");
	        labels.add("Association");
	        labels.add("Employee");
	        data.setLabels(labels);

	        pieModel.setData(data);
	    }
	  public PieChartModel getPieModel() {
	        return pieModel;
	    }

	    public void setPieModel(PieChartModel pieModel) {
	        this.pieModel = pieModel;
	    }
	    
	/*  public void itemSelect(ItemSelectEvent event) {
	        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Item selected",
	                "Item Index: " + event.getItemIndex() + ", DataSet Index:" + event.getDataSetIndex());

	        FacesContext.getCurrentInstance().addMessage(null, msg);
	    }*/

	   
	 
	 public PieChartModel getPieModel1() {
			return pieModel1;
		}
		public void setPieModel1(PieChartModel pieModel1) {
			this.pieModel1 = pieModel1;
		}
		 @RolesAllowed("Employee")
	private void createPieModel1() {
	        pieModel1 = new PieChartModel();
	        ChartData data = new ChartData();

	        PieChartDataSet dataSet = new PieChartDataSet();
	        List<Number> values = new ArrayList<>();
	        values.add(userRepository.nbetudiant("etudiant"));
	        values.add(userRepository.nbjobpublic("publicjob"));
	        values.add(userRepository.nbjobprive("privatejob"));
	        values.add( userRepository.nbretraite("retraite"));
	        dataSet.setData(values);

	        List<String> bgColors = new ArrayList<>();
	        bgColors.add("rgb(255, 99, 132)");
	        bgColors.add("rgb(54, 162, 235)");
	        bgColors.add("rgb(255, 205, 86)");
	        bgColors.add("rgb(201, 203, 207)");
	        dataSet.setBackgroundColor(bgColors);

	        data.addChartDataSet(dataSet);
	        List<String> labels = new ArrayList<>();
	        labels.add("Green");
	        labels.add("Red");
	        labels.add("Blue");
	        labels.add("Yellow");
	        data.setLabels(labels);

	        pieModel1.setData(data);
	    }
	 @RolesAllowed("Employee")
    @RequestMapping(value = { "/StatRole" }, method = RequestMethod.GET)
    
    public String StatNBUsers() {
    	
		
	      
		List<User> users = (List<User>) userRepository.findAll();
		//? renvoie tout type 
		String response = "";

		float nbutilisateur = userRepository.nbUtilisateur();
		float nbclient = userRepository.nbclient(Role.Customer);
		float nbinvestisseur = userRepository.nbinvestisseur(Role.Investor);
		float nbassociation = userRepository.nbassociation(Role.Association);
		float nbemployee = userRepository.nbemployee(Role.Employee);
		

       System.out.println("Le nombre des utilisateur total est :");
       
       System.out.println(nbutilisateur);
       System.out.println("le nombre des clients est: ");
       System.out.println(nbclient);
		float moyClient =(nbclient/ nbutilisateur) *100;
		 System.out.println("Le pourcentage des clients est: ");
	   	float moyinvestisseur =(nbinvestisseur/ nbutilisateur )* 100;
		 System.out.println("Le pourcentage des investisseurs est: ");
	  	 System.out.println(" le nombre des investisseurs est: ");
	       System.out.println(nbinvestisseur);
	    	float moyemployee =((nbemployee* 100)/ nbutilisateur );
			 System.out.println("Le pourcentage des employees est: ");
		  	 System.out.println(" le nombre des employees est: ");
		       System.out.println(nbemployee);
		    	float moyassociation =(nbassociation/ nbutilisateur )* 100;
				 System.out.println("Le pourcentage des associations est: ");
			  	 System.out.println(" le nombre des associations est: ");
			       System.out.println(nbassociation)
	       ;
				return response = "la statistique d'utilisateur par role est : Le pourcentage des employees est:" + moyemployee+"% Le pourcentage des associations est:"
	       +moyassociation+"% Le pourcentage des investisseurs est:"
						+moyinvestisseur+"% Le pourcentage des clients est:" +moyClient+"%";
	       
	    
		
    }
    
    @RequestMapping(value = { "/Statjob" }, method = RequestMethod.GET)
  
    public String StatNBUsersjob() {
    	
		
	
		List<User> users = (List<User>) userRepository.findAll();
		//? renvoie tout type 
		String response = "";

		float nbutilisateur = userRepository.nbUtilisateur();
		float nbetudiant = userRepository.nbetudiant("etudiant");
		float nbjobpublic = userRepository.nbjobpublic("publicjob");
		float nbjobprive = userRepository.nbjobprive("privatejob");
		float nbretraite = userRepository.nbretraite("retraite");
		

       System.out.println("Le nombre des utilisateur total est :");
       
       System.out.println(nbutilisateur);
       System.out.println("le nombre des etudiants est: ");
       System.out.println(nbetudiant);
		float moyEtudiant =(nbetudiant/ nbutilisateur) *100;
		 System.out.println("Le pourcentage des etudiants est: ");
	   	float moyjobpublic =(nbjobpublic/ nbutilisateur )* 100;
		 System.out.println("Le pourcentage des client qui travaillent dans un secteur ethatique est: ");
	  	 System.out.println(" le nombre des client qui travaillent dans un secteur ethatique est: ");
	       System.out.println(nbjobpublic);
	    	float moyjobprive =((nbjobprive* 100)/ nbutilisateur );
			 System.out.println("Le pourcentage des client qui travaillent dans un secteur privée est: ");
		  	 System.out.println(" le nombre des client qui travaillent dans un secteur privée est: ");
		       System.out.println(nbjobprive);
		    	float moyretraite =(nbretraite/ nbutilisateur )* 100;
				 System.out.println("Le pourcentage des clients retraités est: ");
			  	 System.out.println(" le nombre des clients retraités est: ");
			       System.out.println(nbretraite)
	       ;
				return response = "Le pourcentage des etudiants est:  " + moyEtudiant+"% Le pourcentage des client qui travaillent dans un secteur ethatique est:  "
	       +moyjobpublic+"% Le pourcentage des client qui travaillent dans un secteur privée est:"
						+moyjobprive+"% le nombre des clients retraités est:" +nbretraite+"%";
	       
	    
		
    }
    
    @RequestMapping(value = { "/Classification/{username}" }, method = RequestMethod.GET)
    public String classification(@PathVariable("username") String username){
    	return su.ClassifierUser(username);
    	
    }
    

}
