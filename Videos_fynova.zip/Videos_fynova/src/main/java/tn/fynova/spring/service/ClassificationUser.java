package tn.fynova.spring.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.repository.UserRepository;

@Scope(value = "session")
@Controller(value = "ClassificationUser") // Name of the bean in Spring IoC
@ELBeanName(value = "ClassificationUser") 
@Service
@Transactional
public class ClassificationUser implements IClassification{
	@Autowired
	UserRepository userRepository;


	@SuppressWarnings("deprecation")
	@Override
	@Transactional
	public String  ClassifierUser(String username )  {
	User user1= userRepository.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));
	int x=0;
	int y=0;
	int z=0;
	int r=0;
	

	
	switch (userRepository.GetclassProfession(username)) {
	  case "etudiant":
	    x=60;
	    break;
	  case "retraite":
	    x=20;
	    break;
	  case "privatejob":
		 x=60;
		 break;
	  case "publicjob":
		 x=80;
		 break;
	 
	}
	if(userRepository.GetclassAssurance(username)){ 
		z=60;
	}
	 else{ 
		z=30;}
		
	if((userRepository.GetGoodAge(username).getYear()>1961) && (userRepository.GetGoodAge(username).getYear()<1980) ) 
		y=70;
	
	
	else if(userRepository.GetGoodAge(username).getYear()<1961) y=20; 
		
   
	 if((userRepository.GetGoodAge(username).getYear()<2021) && (userRepository.GetGoodAge(username).getYear()>1980))
		y=60;
	else{y=60;}
		
     
	

	r=x+y+z;
	FacesMessage facesMessage= new FacesMessage(" le score de cet utilisateur est:"+r
	    	 );
FacesContext.getCurrentInstance().addMessage(null, facesMessage);
	
	return " le score de cet utilisateur est:"+r;}}


	
	

		 
	 
