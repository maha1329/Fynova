package tn.fynova.spring.authentification.controller;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginPageFilter implements Filter{
	   @Override
	   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,   FilterChain filterChain) throws IOException, ServletException{
	       HttpServletRequest request = (HttpServletRequest) servletRequest;
	       HttpServletResponse response = (HttpServletResponse) servletResponse;
	      // HttpSession session = request.getSession();
	      // UserController userController = (UserController) request.getSession().getAttribute("userController");
	       if(request.getUserPrincipal() != null){ //If user is already authenticated
	                String navigateString = "";
	                if(request.isUserInRole("Employee")){
	                        navigateString = "/pages/admin/simple_pages.xhtml";
	                }else if(request.isUserInRole("Customer")){
	                        navigateString = "/pages/customer/simple_pages.xhtml";
	                }else if(request.isUserInRole("Association")){
	                        navigateString = "/pages/admin/simple_pages.xhtml";
	                }
	                response.sendRedirect(request.getContextPath()+navigateString);
	       } else{
	           filterChain.doFilter(servletRequest, servletResponse);
	       }
	   }

	   @Override
	   public void destroy(){
	   }
	   
	   @Override
	   public void init(FilterConfig filterConfig) throws ServletException{
	   }
	}
