package tn.fynova.spring.authentification.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;



import io.jsonwebtoken.impl.DefaultClaims;
import tn.fynova.spring.entities.HistoryUser;
import tn.fynova.spring.entities.JwtResponse;

import tn.fynova.spring.entities.ResponseMessage;
import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.entities.LoginForm;
import tn.fynova.spring.entities.SignUpForm;
import tn.fynova.spring.service.UserDetailsServiceImpl; 
import tn.fynova.spring.repository.HistoryUserRepository;
import tn.fynova.spring.repository.UserRepository;
import tn.fynova.spring.service.IUserService;
import tn.fynova.spring.service.JwtProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
@RequestMapping("/secure")
@Scope(value = "session")
@Controller(value = "AuthRestAPIs") // Name of the bean in Spring IoC
@ELBeanName(value = "AuthRestAPIs") // Name of the bean used by JSF
@Join(path = "/", to = "/login.jsf")

@Component("AuthRestAPIs")
public class AuthRestAPIs {
	 private static final Logger log = LoggerFactory.getLogger(AuthRestAPIs.class);
	public static User user_now = new User();
	@Autowired
	HistoryUserRepository historyuserRepository;
	@Autowired
	IUserService userdetailsservice;
	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;
	@Autowired
	HistoryUserRepository historyRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtProvider jwtProvider;
	//private User authenticatedUser;
	
	private LoginForm loginRequest;
	
private String username;
private String password;
	public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

	public AuthRestAPIs() {
	loginRequest =new LoginForm();
	signUpRequest=new SignUpForm();
	}

	public LoginForm getLoginRequest() {
		return loginRequest;
	}
	public SignUpForm signUpRequest;
	private boolean loggedIn;



	public SignUpForm getSignUpRequest() {
		return signUpRequest;
	}

	public void setSignUpRequest(SignUpForm signUpRequest) {
		this.signUpRequest = signUpRequest;
	}

	
	@RequestMapping("/signin")
	
	public   String authenticateUser() {
	       log.debug("login");
	        FacesMessage message = null;
	        try {
	            Authentication authentication =
	                    authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(),loginRequest.getPassword()));
	            SecurityContextHolder.getContext().setAuthentication(authentication);
	            password = null;
	            return "welcome";
	        } catch (BadCredentialsException e) {
	            log.error("Bad credentials for user {}", loginRequest.getUsername());
	            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Bad credentials", null);
	        } catch (DisabledException e) {
	            log.error("User {} is disabled", loginRequest.getUsername());
	            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "User is disabled", null);
	        } catch (AuthenticationException e) {
	            log.error("Exception in authentication for user {}", loginRequest.getUsername());
	            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Unable to authenticate", null);
	        }
	        if (message != null) {
	            FacesContext.getCurrentInstance().validationFailed();
	            FacesContext.getCurrentInstance().addMessage("loginFormMessages", message);
	        }

	        return "";}
	@RequestMapping("/logout")
	public String logout() {
		
		 log.debug("logout");
	        SecurityContextHolder.clearContext();
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		HistoryUser his1 =new HistoryUser(user_now.getUserid(),now,2);
		
		historyuserRepository.save(his1);
		return "/login?faces-redirect=true"; 
	}
		
	   private String actionText;

	    public String getActionText() {
	        return actionText;
	    }

	    public void setActionText(String actionText) {
	        this.actionText = actionText;
	    }

	    @PreAuthorize("hasRole('association')")
	    public String testUserAction(){
	        actionText = "User action successfull";
	        return "";
	    }

	    @PreAuthorize("hasRole('investor')")
	    public String testAdminAction(){
	        actionText = "Admin action successfull";
	        return "";
	    }
	    @PreAuthorize("hasRole('customer')")
	    public String testcustomerAction(){
	        actionText = "Admin action successfull";
	        return "";
	    }
	    @PreAuthorize("hasRole('employee')")
	    public String testSuperuserAction(){
	        actionText = "Superuser action successfull";
	        return "";
	    }
		//authenticatedUser =userdetailsservice.authenticate(username, password);*/
   		
	
	/*@RequestMapping("/signin")
	public String validateUsernamePassword() {
		boolean valid =userdetailsservice.authenticate(username, password);
		
		if (valid) {
			HttpSession session = SessionUtils.getSession();
			session.setAttribute("username", user);
			return "admin";
		} else {
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_WARN,
							"Incorrect Username and Passowrd",
							"Please enter correct username and Password"));
			return "login";
		}
	}*/
    /*  @RequestMapping("/signin")

	public String doLogin() {
		authenticatedUser =userdetailsservice.authenticate(username, password);
		String navigateTo = "null"; 
		if (authenticatedUser != null && authenticatedUser.getUserrole() == Role.Customer) {
		navigateTo = "/pages/admin/welcome?faces-redirect=true"; 
		loggedIn = true; }
		else {
		FacesMessage facesMessage= new FacesMessage("Bad Credentials: "
			    	+ "please check your email/password and try again");
		FacesContext.getCurrentInstance().addMessage("form:btn", facesMessage);
		}
		return navigateTo; 
		} */
      
	public void setLoginRequest(LoginForm loginRequest) {
		this.loginRequest = loginRequest;
	}

	@RequestMapping("/signup")
  
	public ResponseEntity<?> registerUser( @RequestBody SignUpForm signUpRequest) {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Username is already taken!"),
					HttpStatus.BAD_REQUEST);
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Email is already in use!"),
					HttpStatus.BAD_REQUEST);
		}

		// Creating user's account
		/*User user = new User(signUpRequest.getUserfirstname(), signUpRequest.getUsername(), signUpRequest.getUserlastname(), signUpRequest.getEmail(),
				encoder.encode(signUpRequest.getUserpassword()), signUpRequest.getUserphone(), 
				signUpRequest.getUserbirthday(), signUpRequest.getUsercin(),
				signUpRequest.getUserrole());
		userRepository.save(user);*/
		User user=new User(encoder.encode(signUpRequest.getPassword()),
				signUpRequest.getEmail(),
				signUpRequest.getUserphone(),
				signUpRequest.getUsername(),
				signUpRequest.getUserfirstname(),
				signUpRequest.getUserlastname(),
				signUpRequest.getUsercin(),
				signUpRequest.getEmployeegrade(),
				signUpRequest.getUserbirthday(),
				signUpRequest.getUserrole(),
				signUpRequest.getJob(),
				signUpRequest.getCustomer_origin(),
				signUpRequest.getAssociation_fiscalNumber(),
				signUpRequest.getAssociation_name(),
				signUpRequest.getAssociation_description(),
				signUpRequest.getAssociation_fondationDate(),
				signUpRequest.getAssociation_customersNumber(),
				signUpRequest.isAssurance_vie(),
				//signUpRequest.getUser_claims(),
				//signUpRequest.getUser_accounts(),
				//signUpRequest.getUser_projects(),
				signUpRequest.getUserid());
						userRepository.save(user);
					/*	HistoryUser userhi=new HistoryUser(
								HistoryUser.getEmail(),
								HistoryUser.getUsername(),
								HistoryUser.getUserfirstname(),
								HistoryUser.getUserlastname(),
								HistoryUser.getUserrole(),
								HistoryUser.getUser_id());
										HistoryRepository.save(user);*/

		return new ResponseEntity<>(new ResponseMessage("User registered successfully!"), HttpStatus.OK);

}
	/*public User getAuthenticatedUser() {
		return authenticatedUser;
	}
	public Boolean getLoggedIn() {
		return loggedIn;
	}
	public void setLoggedIn(Boolean loggedIn) {
		this.loggedIn = loggedIn;
	}
	public void setAuthenticatedUser(User authenticatedUser) {
		this.authenticatedUser = authenticatedUser;
	}*/
	
}
