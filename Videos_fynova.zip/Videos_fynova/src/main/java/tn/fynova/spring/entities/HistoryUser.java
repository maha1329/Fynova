package tn.fynova.spring.entities;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class HistoryUser {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private int user_id;
	
	
	private LocalDateTime datetime;
	//sprivate LocalDateTime logintime;
	//private LocalDateTime logouttime;
	// 0 logout , 1 log in 
	private int type_connection;
	
	public HistoryUser() {}
	
	public HistoryUser(int user_id, LocalDateTime now, int type_connection) {
		super();
		this.user_id = user_id;
		this.datetime = now;
		this.type_connection = type_connection;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
	public int getType_connection() {
		return type_connection;
	}
	public void setType_connection(int type_connection) {
		this.type_connection = type_connection;
	}
	
	

	
	
	
	
}
