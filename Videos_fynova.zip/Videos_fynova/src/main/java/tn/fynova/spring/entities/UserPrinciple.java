package tn.fynova.spring.entities;




import com.fasterxml.jackson.annotation.JsonIgnore;

import tn.fynova.spring.entities.Account;
import tn.fynova.spring.entities.Claim;
import tn.fynova.spring.entities.Grade;
import tn.fynova.spring.entities.Origin;
import tn.fynova.spring.entities.Project;
import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class UserPrinciple implements UserDetails {
	private static final long serialVersionUID = 1L;

	public int user_id;


	@JsonIgnore
	private String password;


	private String email;
	private int userphone;
	private String username;
	private String userfirstname;
	private String userlastname;
	private int usercin;
	@Enumerated
	private Grade employeegrade;
	
	@Temporal(TemporalType.DATE)
	private Date userbirthday;
	
	@Enumerated(EnumType.STRING)
	private Role userrole;
	
    private String job;
	
	
    @Enumerated(EnumType.STRING)
	private Origin customer_origin;

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getUserphone() {
		return userphone;
	}

	public void setUserphone(int userphone) {
		this.userphone = userphone;
	}

	public String getUserfirstname() {
		return userfirstname;
	}

	public void setUserfirstname(String userfirstname) {
		this.userfirstname = userfirstname;
	}

	public String getUserlastname() {
		return userlastname;
	}

	public void setUserlastname(String userlastname) {
		this.userlastname = userlastname;
	}

	public int getUsercin() {
		return usercin;
	}

	public void setUsercin(int usercin) {
		this.usercin = usercin;
	}

	public Grade getEmployeegrade() {
		return employeegrade;
	}

	public void setEmployeegrade(Grade employeegrade) {
		this.employeegrade = employeegrade;
	}

	public Date getUserbirthday() {
		return userbirthday;
	}

	public void setUserbirthday(Date userbirthday) {
		this.userbirthday = userbirthday;
	}

	public Role getUserrole() {
		return userrole;
	}

	public void setUserrole(Role userrole) {
		this.userrole = userrole;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Origin getCustomer_origin() {
		return customer_origin;
	}

	public void setCustomer_origin(Origin customer_origin) {
		this.customer_origin = customer_origin;
	}

	public int getAssociation_fiscalNumber() {
		return association_fiscalnumber;
	}

	public void setAssociation_fiscalNumber(int association_fiscalNumber) {
		this.association_fiscalnumber = association_fiscalNumber;
	}

	public String getAssociation_name() {
		return association_name;
	}

	public void setAssociation_name(String association_name) {
		this.association_name = association_name;
	}

	public String getAssociation_description() {
		return association_description;
	}

	public void setAssociation_description(String association_description) {
		this.association_description = association_description;
	}

	public Date getAssociation_fondationDate() {
		return association_fondationdate;
	}

	public void setAssociation_fondationDate(Date association_fondationDate) {
		this.association_fondationdate = association_fondationDate;
	}

	public int getAssociation_customersNumber() {
		return association_customersnumber;
	}

	public void setAssociation_customersNumber(int association_customersNumber) {
		this.association_customersnumber = association_customersNumber;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	private int association_fiscalnumber;
	
	private String association_name;
	private String association_description;
	
	@Temporal(TemporalType.DATE)
	private Date association_fondationdate;
	private int association_customersnumber;
  
    
    public UserPrinciple(int user_id, String userpassword, String email, int userphone, String username,
			String userfirstname, String userlastname, int usercin, Grade employeegrade, Date userbirthday,
			Role userrole, String job, Origin customer_origin, int association_fiscalNumber, String association_name,
			String association_description, Date association_fondationDate, int association_customersNumber) {
		super();
		this.user_id = user_id;
		this.password = userpassword;
		this.email = email;
		this.userphone = userphone;
		this.username = username;
		this.userfirstname = userfirstname;
		this.userlastname = userlastname;
		this.usercin = usercin;
		this.employeegrade = employeegrade;
		this.userbirthday = userbirthday;
		this.userrole = userrole;
		this.job = job;
		this.customer_origin = customer_origin;
		this.association_fiscalnumber = association_fiscalNumber;
		this.association_name = association_name;
		this.association_description = association_description;
		this.association_fondationdate = association_fondationDate;
		this.association_customersnumber = association_customersNumber;
	}

	public static UserPrinciple build(User user) {
       Role authorities = user.getUserrole();

        return new UserPrinciple(
        		user.getUserid(),
        		user.getPassword(),
        		user.getEmail(),
        		user.getUserphone(),
        		user.getUsername(),
        		user.getUserfirstname(),
        		user.getUserlastname(),
        		user.getUsercin(),
        		user.getEmployeegrade(),
        		user.getUserbirthday(),
        		user.getUserrole(),
        		user.getJob(),
        		user.getCustomer_origin(),
        		user.getAssociation_fiscalNumber(),
        		user.getAssociation_name(),
        		user.getAssociation_description(),
        	    user.getAssociation_fondationDate(),
        		user.getAssociation_customersNumber()
        );
    }

    public int getId() {
        return user_id;
    }

    public String getName() {
        return userfirstname;
    }

   

	/*List<Claim> user_claims;
	List<Account> user_accounts;
	List<Project> user_projects;

	

	public List<Claim> getUser_claims() {
		return user_claims;
	}

	public void setUser_claims(List<Claim> user_claims) {
		this.user_claims = user_claims;
	}

	public List<Account> getUser_accounts() {
		return user_accounts;
	}

	public void setUser_accounts(List<Account> user_accounts) {
		this.user_accounts = user_accounts;
	}

	public List<Project> getUser_projects() {
		return user_projects;
	}

	public void setUser_projects(List<Project> user_projects) {
		this.user_projects = user_projects;
	}*/

	@Override
    public String getUsername() {
        return username;
    }

   @Override
    public String getPassword() {
        return password;
    }


    
  

	@Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        UserPrinciple user = (UserPrinciple) o;
        return Objects.equals(user_id, user.user_id);
    }
	/*@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		 TODO Auto-generated method stub
		return null;
    private User user;*/
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
/*	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		 / Set<Role> roles = user.getRoles();
	        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
	         
	        for (Role role : roles) {
	            authorities.add(new SimpleGrantedAuthority(role.name()));
	        }
	         
	        return null;
	}*/}}