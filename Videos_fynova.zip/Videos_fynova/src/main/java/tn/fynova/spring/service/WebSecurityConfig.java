package tn.fynova.spring.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;


import tn.fynova.spring.entities.HistoryUser;
import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.entities.UserPrinciple;
import tn.fynova.spring.repository.HistoryUserRepository;
import tn.fynova.spring.service.JwtAuthEntryPoint;
import tn.fynova.spring.service.JwtAuthTokenFilter;
import tn.fynova.spring.service.UserDetailsServiceImpl;




@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(
		prePostEnabled = true
)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	public static User user_now = new User();
	@Autowired
	HistoryUserRepository historyuserRepository;
    @Autowired
    UserDetailsServiceImpl userDetailsService;
    @Autowired
    private MyAuthenticationSucessHandler authenticationSucessHandler;
    @Autowired
    private JwtAuthEntryPoint unauthorizedHandler;
    @Autowired
    private MyAuthenticationFailureHandler authenticationFailureHandler;
    @Bean
    public JwtAuthTokenFilter authenticationJwtTokenFilter() {
        return new JwtAuthTokenFilter();
    }
 /*   @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());
         
        return authProvider;
    }*/

    @Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
        
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors().and().csrf().disable().
                authorizeRequests()
               .antMatchers("/javax.faces.resource/**","/secure/**","/login.jsf","/signup.jsf","/","pages-login.html","/admin.xhtml","Login1.xhtml").permitAll()
              // .antMatchers("/pages/admin/list.jsf").hasAuthority("Employee")
               
               //.antMatchers("/pages/admin/**").permitAll()
               .antMatchers("/pages/association/**").access("hasRole('ROLE_Association')")
               .antMatchers("/pages/employee/**").access("hasRole('ROLE_Employee')")
               .antMatchers("/pages/customer/**").access("hasRole('ROLE_Customer')")
                .antMatchers("/pages/investor/**").access("hasRole('ROLE_Investor')")
                .anyRequest().authenticated()
                .and()
                .exceptionHandling().accessDeniedPage("/error.jsf")
               .and().formLogin().loginPage("/login.jsf").loginProcessingUrl("/login.xhtml?error=true").permitAll()
               // .successHandler(authenticationSucessHandler)
                //.failureHandler(authenticationFailureHandler)
                
                
                
                
               //.exceptionHandling().authenticationEntryPoint(unauthorizedHandler)
               
                .and()
                .logout()
                .logoutUrl("/secure/logout")          
                .logoutSuccessHandler(new AuthentificationLogoutSuccessHandler()).permitAll()
                //.logoutSuccessUrl("/login.jsf").deleteCookies(JSESSIONID)
                .invalidateHttpSession(true)
               .and()
               .sessionManagement().maximumSessions(1);
               
        
        http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
        

        
       
    }
    
    private class AuthentificationLogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {
        @Override
        public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response,
                                    Authentication authentication) throws IOException, ServletException {
        	
            response.setStatus(HttpServletResponse.SC_OK);
            System.out.println(" vous avez déconnecté  ");
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
 		   LocalDateTime now = LocalDateTime.now();  
 		HistoryUser his1 =new HistoryUser(user_now.getUserid(),now,2);
 		
 		historyuserRepository.save(his1);
 	
        }
    }
    }
