package tn.fynova.spring.service;

import java.util.Optional;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import tn.fynova.spring.entities.User;
import tn.fynova.spring.repository.UserRepository;
import tn.fynova.spring.service.UserServiceImpl;

public class AppAuthProvider extends DaoAuthenticationProvider {
	@Autowired
	UserRepository userpository;
    @Autowired
    UserServiceImpl userDetailsService;
    @Override
    public Authentication authenticate(Authentication authentication)  {
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
        int id = auth.hashCode();
        String password = auth.getCredentials()
                .toString();
        Optional<User> user = userpository.findById(id);
        if (user == null) {
    		FacesMessage facesMessage= new FacesMessage("Bad Credentials: "
			    	+ "please check your email/password and try again");
		FacesContext.getCurrentInstance().addMessage("form:btn", facesMessage);   
        }
        return new UsernamePasswordAuthenticationToken(user, null);
    }
    @Override
    public boolean supports(Class<?> authentication) {
        return true;
    }
}
