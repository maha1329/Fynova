package tn.fynova.spring.repository;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import tn.fynova.spring.entities.HistoryUser;
import tn.fynova.spring.entities.User;
@Repository
public interface HistoryUserRepository extends CrudRepository<HistoryUser,Integer>{ 
	
	//SELECT * from Userhistory u  '2011-10-08 12:35:45' AS datetime1, '2011-10-07 16:00:25' AS datetime2, TIMEDIFF('2011-10-08 12:35:45', '2011-10-07 16:00:25') as difference;

	
	
	
	
	@Modifying
	@Transactional
	@Query(value =	 
			  "SELECT count(*) FROM history_user u WHERE u.user_id=:id " , nativeQuery=true) 
			//int CountUserLogIn (@Param("") int id,@Param("d") String d);
	int CountUserLogIn (@Param("id") int id);
	
	
	
	
	
	//@Query(
		//	  value = "SELECT count(*) FROM Userhistory u WHERE u.data= and u.id=:id ", 
			//  nativeQuery = true)
	// int CountUserLogIn (@Param("id") int id);
	
}
