package tn.fynova.spring.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class Account implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accountid;
	private double accountbalance;
	@Temporal(TemporalType.DATE)
	private Date creationDate;
	@Enumerated
	private AccountType accounttype;
	
	public int getAccountid() {
		return accountid;
	}

	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}

	public double getAccountbalance() {
		return accountbalance;
	}

	public void setAccountbalance(double accountbalance) {
		this.accountbalance = accountbalance;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public AccountType getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(AccountType accounttype) {
		this.accounttype = accounttype;
	}

	public User getAccount_user() {
		return account_user;
	}

	public void setAccount_user(User accountuser) {
		this.account_user = account_user;
	}

	
	@ManyToOne
	private User account_user;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="credit_account")
	private List<Credit> accountcredits;
	
	//@OneToMany(cascade = CascadeType.ALL, mappedBy="transaction_account")
	//private List<Transaction> account_transactions;
	
}
