package tn.fynova.spring.entities;

public enum Operation {
	Transfert,Payment
}
