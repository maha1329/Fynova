package tn.fynova.spring.entities;

public enum Grade {
	Admin,Agent
}
