package tn.fynova.spring.entities;

public enum AccountType {
	Saving,Current
}
