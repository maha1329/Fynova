package tn.fynova.spring.service;

public class MailConstants {
	// Sender email here:  
    public static final String MY_EMAIL = "houssem.maalej1@esprit.tn";
 
    // Sender password!!
    public static final String MY_PASSWORD = "193JMT2672";
 
    // And receiver!
    public static final String FRIEND_EMAIL = "maalej.housssem@gmail.com";

}
