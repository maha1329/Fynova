package tn.fynova.spring.entities;

public enum Origin {
	fromAssociation,notFromAssocication
}
