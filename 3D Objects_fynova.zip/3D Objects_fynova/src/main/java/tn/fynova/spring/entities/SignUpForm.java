package tn.fynova.spring.entities;


import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import tn.fynova.spring.entities.Account;
import tn.fynova.spring.entities.Claim;
import tn.fynova.spring.entities.Grade;
import tn.fynova.spring.entities.Origin;
import tn.fynova.spring.entities.Project;
import tn.fynova.spring.entities.Role;





public class SignUpForm {

	private String email;
	private String password;
	private int userphone;
	private String username;
	private String userfirstname;
	private String userlastname;
	private int usercin;
	/*List<Claim> user_claims;
	List<Account> user_accounts;
	List<Project> user_projects;*/
	private int user_id;
	private boolean assurance_vie;
	public boolean isAssurance_vie() {
		return assurance_vie;
	}
	public void setAssurance_vie(boolean assurance_vie) {
		this.assurance_vie = assurance_vie;
	}
	/*public List<Claim> getUser_claims() {
		return user_claims;
	}
	public void setUser_claims(List<Claim> user_claims) {
		this.user_claims = user_claims;
	}
	public List<Account> getUser_accounts() {
		return user_accounts;
	}
	public void setUser_accounts(List<Account> user_accounts) {
		this.user_accounts = user_accounts;
	}
	public List<Project> getUser_projects() {
		return user_projects;
	}
	public void setUser_projects(List<Project> user_projects) {
		this.user_projects = user_projects;
	}*/
	public int getUserid() {
		return user_id;
	}
	public void setUserid(int user_id) {
		this.user_id = user_id;
	}
	@Enumerated
	private Grade employeegrade;
	
	@Temporal(TemporalType.DATE)
	private Date userbirthday;
	
	@Enumerated(EnumType.STRING)
	private Role userrole;
	
    private String job;
	
	
    @Enumerated(EnumType.STRING)
	private Origin customer_origin;

	private int association_fiscalnumber;
	
	private String association_name;
	private String association_description;
	
	@Temporal(TemporalType.DATE)
	private Date association_fondationdate;
	private int association_customersnumber;
	
	
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getUserphone() {
		return userphone;
	}
	public void setUserphone(int userphone) {
		this.userphone = userphone;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserfirstname() {
		return userfirstname;
	}
	public void setUserfirstname(String userfirstname) {
		this.userfirstname = userfirstname;
	}
	public String getUserlastname() {
		return userlastname;
	}
	public void setUserlastname(String userlastname) {
		this.userlastname = userlastname;
	}
	public int getUsercin() {
		return usercin;
	}
	public void setUsercin(int usercin) {
		this.usercin = usercin;
	}
	public Grade getEmployeegrade() {
		return employeegrade;
	}
	public void setEmployeegrade(Grade employeegrade) {
		this.employeegrade = employeegrade;
	}
	public Date getUserbirthday() {
		return userbirthday;
	}
	public void setUserbirthday(Date userbirthday) {
		this.userbirthday = userbirthday;
	}
	public Role getUserrole() {
		return userrole;
	}
	public void setUserrole(Role userrole) {
		this.userrole = userrole;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Origin getCustomer_origin() {
		return customer_origin;
	}
	public void setCustomer_origin(Origin customer_origin) {
		this.customer_origin = customer_origin;
	}
	public int getAssociation_fiscalNumber() {
		return association_fiscalnumber;
	}
	public void setAssociation_fiscalNumber(int association_fiscalNumber) {
		this.association_fiscalnumber = association_fiscalNumber;
	}
	public String getAssociation_name() {
		return association_name;
	}
	public void setAssociation_name(String association_name) {
		this.association_name = association_name;
	}
	public String getAssociation_description() {
		return association_description;
	}
	public void setAssociation_description(String association_description) {
		this.association_description = association_description;
	}
	public Date getAssociation_fondationDate() {
		return association_fondationdate;
	}
	public void setAssociation_fondationDate(Date association_fondationDate) {
		this.association_fondationdate = association_fondationDate;
	}
	public int getAssociation_customersNumber() {
		return association_customersnumber;
	}
	public void setAssociation_customersNumber(int association_customersNumber) {
		this.association_customersnumber = association_customersNumber;
	}
	

}
