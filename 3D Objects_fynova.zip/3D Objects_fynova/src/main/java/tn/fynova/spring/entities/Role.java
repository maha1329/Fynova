package tn.fynova.spring.entities;

public enum Role {
	Customer,Employee,Investor,Association
}
