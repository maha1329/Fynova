package tn.fynova.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import tn.fynova.spring.repository.HistoryUserRepository;

@Service
public class HistoryUserService implements Historyuser {
//@Autowired 
 //private final HistoryUserRepository historyuserrepository;




}
