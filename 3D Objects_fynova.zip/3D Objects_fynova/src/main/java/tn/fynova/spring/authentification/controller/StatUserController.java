package tn.fynova.spring.authentification.controller;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.repository.UserRepository;
import tn.fynova.spring.service.ClassificationUser;

@RestController
public class StatUserController {
	
    @Autowired
    private  UserRepository userRepository;
    @Autowired
    private ClassificationUser su;
 
	public StatUserController(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
  /* // @GetMapping("/StatRole")
    public long getAllUsers(@PathVariable("userrole")  Role role){
        return userRepository.countByRole(role);
    }*/
	 @RolesAllowed("Employee")
    @RequestMapping(value = { "/StatRole" }, method = RequestMethod.GET)
    
    public String StatNBUsers() {
    	
		
	      
		List<User> users = (List<User>) userRepository.findAll();
		//? renvoie tout type 
		String response = "";

		float nbutilisateur = userRepository.nbUtilisateur();
		float nbclient = userRepository.nbclient(Role.Customer);
		float nbinvestisseur = userRepository.nbinvestisseur(Role.Investor);
		float nbassociation = userRepository.nbassociation(Role.Association);
		float nbemployee = userRepository.nbemployee(Role.Employee);
		

       System.out.println("Le nombre des utilisateur total est :");
       
       System.out.println(nbutilisateur);
       System.out.println("le nombre des clients est: ");
       System.out.println(nbclient);
		float moyClient =(nbclient/ nbutilisateur) *100;
		 System.out.println("Le pourcentage des clients est: ");
	   	float moyinvestisseur =(nbinvestisseur/ nbutilisateur )* 100;
		 System.out.println("Le pourcentage des investisseurs est: ");
	  	 System.out.println(" le nombre des investisseurs est: ");
	       System.out.println(nbinvestisseur);
	    	float moyemployee =((nbemployee* 100)/ nbutilisateur );
			 System.out.println("Le pourcentage des employees est: ");
		  	 System.out.println(" le nombre des employees est: ");
		       System.out.println(nbemployee);
		    	float moyassociation =(nbassociation/ nbutilisateur )* 100;
				 System.out.println("Le pourcentage des associations est: ");
			  	 System.out.println(" le nombre des associations est: ");
			       System.out.println(nbassociation)
	       ;
				return response = "la statistique d'utilisateur par role est : Le pourcentage des employees est:" + moyemployee+"% Le pourcentage des associations est:"
	       +moyassociation+"% Le pourcentage des investisseurs est:"
						+moyinvestisseur+"% Le pourcentage des clients est:" +moyClient+"%";
	       
	    
		
    }
    
    @RequestMapping(value = { "/Statjob" }, method = RequestMethod.GET)
  
    public String StatNBUsersjob() {
    	
		
	
		List<User> users = (List<User>) userRepository.findAll();
		//? renvoie tout type 
		String response = "";

		float nbutilisateur = userRepository.nbUtilisateur();
		float nbetudiant = userRepository.nbetudiant("etudiant");
		float nbjobpublic = userRepository.nbjobpublic("publicjob");
		float nbjobprive = userRepository.nbjobprive("privatejob");
		float nbretraite = userRepository.nbretraite("retraite");
		

       System.out.println("Le nombre des utilisateur total est :");
       
       System.out.println(nbutilisateur);
       System.out.println("le nombre des etudiants est: ");
       System.out.println(nbetudiant);
		float moyEtudiant =(nbetudiant/ nbutilisateur) *100;
		 System.out.println("Le pourcentage des etudiants est: ");
	   	float moyjobpublic =(nbjobpublic/ nbutilisateur )* 100;
		 System.out.println("Le pourcentage des client qui travaillent dans un secteur ethatique est: ");
	  	 System.out.println(" le nombre des client qui travaillent dans un secteur ethatique est: ");
	       System.out.println(nbjobpublic);
	    	float moyjobprive =((nbjobprive* 100)/ nbutilisateur );
			 System.out.println("Le pourcentage des client qui travaillent dans un secteur privée est: ");
		  	 System.out.println(" le nombre des client qui travaillent dans un secteur privée est: ");
		       System.out.println(nbjobprive);
		    	float moyretraite =(nbretraite/ nbutilisateur )* 100;
				 System.out.println("Le pourcentage des clients retraités est: ");
			  	 System.out.println(" le nombre des clients retraités est: ");
			       System.out.println(nbretraite)
	       ;
				return response = "Le pourcentage des etudiants est:  " + moyEtudiant+"% Le pourcentage des client qui travaillent dans un secteur ethatique est:  "
	       +moyjobpublic+"% Le pourcentage des client qui travaillent dans un secteur privée est:"
						+moyjobprive+"% le nombre des clients retraités est:" +nbretraite+"%";
	       
	    
		
    }
    
    @RequestMapping(value = { "/Classification" }, method = RequestMethod.GET)
    public User classification(){
    	return su.Classification();
    	
    }
    

}
