package tn.fynova.spring.service;

public interface Historyuser {

}
