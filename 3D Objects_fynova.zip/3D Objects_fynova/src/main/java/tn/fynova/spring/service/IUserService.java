package tn.fynova.spring.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;


public interface IUserService {
	User addUser(User e);
	void deleteUser(int id);
	List<User> retrieveAllUsers();
	Optional<User>  retrieveUser(int id);
	//long totcountByRole(Role role);
	

}
