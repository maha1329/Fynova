package tn.fynova.spring.service;

import java.util.List;
import java.util.Optional;


import tn.fynova.spring.entities.HistoryUser;

public interface IhistoryUserService {

	HistoryUser addHistoryUser(HistoryUser e);
	void deleteHistoryUser(int id);
	List<HistoryUser> retrieveAllHistory();
	Optional<HistoryUser> retrieveHistory(int id);
	int CountUserLogIn(int id, String s);

}
