package tn.fynova.spring.service;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import tn.fynova.spring.entities.HistoryUser;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.entities.UserPrinciple;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.fynova.spring.repository.HistoryUserRepository;
import tn.fynova.spring.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	public User user_now= new User();
	@Autowired
	UserRepository userRepository;
	@Autowired
	HistoryUserRepository historyuserRepository;
	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		User user = userRepository.findByUsername(username).orElseThrow(
				
				() -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   System.out.println("/////");
		HistoryUser his =new HistoryUser(user.getUserid(),now,1);
		user_now =user;
		
		historyuserRepository.save(his);
		
		
		
		return UserPrinciple.build(user);
	}
}
	  
		
		
	
     
			
 			

	


