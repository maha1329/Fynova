package tn.fynova.spring.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import tn.fynova.spring.entities.Role;
import tn.fynova.spring.entities.User;
import tn.fynova.spring.repository.UserRepository;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.donut.DonutChartDataSet;
import org.primefaces.model.charts.donut.DonutChartModel;

@Service
@Transactional
public class ClassificationUser {
	@Autowired
	UserRepository userRepository;

	public User Classification() {
		Iterable<User> users =  userRepository.findAll();
		User U1= new User();
		String et="etudiant";
		for (User u : users) {
			if (u.getJob()=="retraite") {
				 System.out.println(" les bon profils  ");
				 
        u.getUserid();
        return u;
			}
			if ((userRepository.GetBadAge(u.getUserbirthday()) != null)
					&& (userRepository.GetclassProfession(u.getJob()) == "retraite")) {
				 System.out.println(" les mauvais profils  ");
				 U1=u;
			}
			
			if ((userRepository.GetMoyenAge(u.getUserbirthday()) != null)
					&& (userRepository.GetclassProfession(u.getJob()) == "Job")) {
				 System.out.println(" les Moyen profils  ");
				 U1=u;
			}
			
			
			
		}
		
		return U1;
		
	}
	}
