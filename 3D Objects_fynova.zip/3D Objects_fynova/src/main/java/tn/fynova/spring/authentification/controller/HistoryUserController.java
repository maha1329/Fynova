package tn.fynova.spring.authentification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import tn.fynova.spring.repository.HistoryUserRepository;

@CrossOrigin
@RestController
public class HistoryUserController {
	
	@Autowired
	HistoryUserRepository historyuserRepository;
	

	public HistoryUserController(HistoryUserRepository historyuserRepository) {
		super();
		this.historyuserRepository = historyuserRepository;
	}

	/*@GetMapping("/historyuser/{id}")
    public int CountUserLogIn(@PathVariable("id") int id, @RequestBody String s){
        return historyuserRepository.CountUserLogIn(id,s);
    }*/
	@GetMapping("/historyuser/{id}")
    public int CountUserLogIn(@PathVariable("id") int id){
        return historyuserRepository.CountUserLogIn(id);
    }
	

}
