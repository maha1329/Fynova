package tn.fynova.spring.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class User implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int user_id;
	private String password;
	private String email;
	private int userphone;
	private String username;
	private String userfirstname;
	private String userlastname;
	private int usercin;
	@Enumerated
	private Grade employeegrade;
	
	@Temporal(TemporalType.DATE)
	private Date userbirthday;
	
	@Enumerated(EnumType.STRING)
	private Role userrole;
	
    private String job;
    private Boolean assurance_vie;
	
	
	public Boolean getAssurance_vie() {
		return assurance_vie;
	}



	public void setAssurance_vie(Boolean assurance_vie) {
		assurance_vie = assurance_vie;
	}
	@Enumerated(EnumType.STRING)
	private Origin customer_origin;

	private int association_fiscalnumber;
	
	private String association_name;
	private String association_description;
	
	@Temporal(TemporalType.DATE)
	private Date association_fondationdate;
	private int association_customersnumber;
	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="claim_user")
	private List<Claim> user_claims;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="account_user")
	private List<Account> user_accounts;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="user_project")
	private List<Project> user_projects;
	
	
	
	public User(String userpassword, String email, int userphone, String username, String userfirstname,
			String userlastname, int usercin, Grade employeegrade, Date userbirthday, Role userrole, String job,
			Origin customer_origin, int association_fiscalNumber, String association_name,
			String association_description, Date association_fondationDate, int association_customersNumber,boolean assurance_vie,
			//List<Claim> user_claims, List<Account> user_accounts, List<Project> user_projects
			int user_id ) {
		super();
		this.password = userpassword;
		this.email = email;
		this.userphone = userphone;
		this.username = username;
		this.userfirstname = userfirstname;
		this.userlastname = userlastname;
		this.usercin = usercin;
		this.employeegrade = employeegrade;
		this.userbirthday = userbirthday;
		this.userrole = userrole;
		this.job = job;
		this.customer_origin = customer_origin;
		this.association_fiscalnumber = association_fiscalNumber;
		this.association_name = association_name;
		this.association_description = association_description;
		this.association_fondationdate = association_fondationDate;
		this.association_customersnumber = association_customersNumber;
		this.assurance_vie = assurance_vie;
		//this.user_claims = user_claims;
		//this.user_accounts = user_accounts;
		//this.user_projects = user_projects;
		this.user_id=user_id;
	}



	/*public User(String userfirstname2, String username2, String userlastname2, String useremail2, String encode,
			int userphone2, Date userbirthday2, int usercin2, Role role, int i, String string, int j, Date date, String string2, Origin origin, Grade grade, String string3) {
		super();
		this.userfirstname = userfirstname2;
		this.username = username;
		this.userlastname = userlastname2;
		this.email = useremail2;
		this.userpassword = encode;
		this.userphone = userphone2;
		this.userbirthday = userbirthday2;
		this.usercin = userphone2;
		this.userrole = role;
	}*/
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	
	


	
	

	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Origin getCustomer_origin() {
		return customer_origin;
	}
	public void setCustomer_origin(Origin customer_origin) {
		this.customer_origin = customer_origin;
	}
	public int getAssociation_fiscalNumber() {
		return association_fiscalnumber;
	}
	public void setAssociation_fiscalNumber(int association_fiscalNumber) {
		this.association_fiscalnumber = association_fiscalNumber;
	}
	public String getAssociation_name() {
		return association_name;
	}
	public void setAssociation_name(String association_name) {
		this.association_name = association_name;
	}
	public String getAssociation_description() {
		return association_description;
	}
	public void setAssociation_description(String association_description) {
		this.association_description = association_description;
	}
	public Date getAssociation_fondationDate() {
		return association_fondationdate;
	}
	public void setAssociation_fondationDate(Date association_fondationDate) {
		this.association_fondationdate = association_fondationDate;
	}
	public int getAssociation_customersNumber() {
		return association_customersnumber;
	}
	public void setAssociation_customersNumber(int association_customersNumber) {
		this.association_customersnumber = association_customersNumber;
	}
	public User(String password, String email, int userphone, String username, String userfirstname,
			String userlastname, int usercin, Grade employeegrade, Date userbirthday, Role userrole, String job,
			Origin customer_origin, int association_fiscalnumber, String association_name,
			String association_description, Date association_fondationdate, int association_customersnumber,boolean assurance_vie,
			List<Claim> user_claims, List<Account> user_accounts, List<Project> user_projects) {
		super();
		this.password = password;
		this.email = email;
		this.userphone = userphone;
		this.username = username;
		this.userfirstname = userfirstname;
		this.userlastname = userlastname;
		this.usercin = usercin;
		this.employeegrade = employeegrade;
		this.userbirthday = userbirthday;
		this.userrole = userrole;
		this.job = job;
		this.customer_origin = customer_origin;
		this.association_fiscalnumber = association_fiscalnumber;
		this.association_name = association_name;
		this.association_description = association_description;
		this.association_fondationdate = association_fondationdate;
		this.association_customersnumber = association_customersnumber;
		this.assurance_vie=assurance_vie;
		this.user_claims = user_claims;
		this.user_accounts = user_accounts;
		this.user_projects = user_projects;
	}



	public User(int user_id, String password, String email, int userphone, String username, String userfirstname,
			String userlastname, int usercin, Grade employeegrade, Date userbirthday, Role userrole, String job,
			Origin customer_origin, int association_fiscalnumber, String association_name,
			String association_description, Date association_fondationdate, int association_customersnumber,boolean assurance_vie,
			List<Claim> user_claims, List<Account> user_accounts, List<Project> user_projects) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.email = email;
		this.userphone = userphone;
		this.username = username;
		this.userfirstname = userfirstname;
		this.userlastname = userlastname;
		this.usercin = usercin;
		this.employeegrade = employeegrade;
		this.userbirthday = userbirthday;
		this.userrole = userrole;
		this.job = job;
		this.customer_origin = customer_origin;
		this.association_fiscalnumber = association_fiscalnumber;
		this.association_name = association_name;
		this.association_description = association_description;
		this.association_fondationdate = association_fondationdate;
		this.association_customersnumber = association_customersnumber;
		this.assurance_vie=assurance_vie;
		this.user_claims = user_claims;
		this.user_accounts = user_accounts;
		this.user_projects = user_projects;
	}



	public User() {
		super();
		// TODO Auto-generated constructor stub
	}



	public int getUserid() {
		return user_id;
	}
	public void setUserid(int userid) {
		this.user_id = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String useremail) {
		this.email = useremail;
	}
	public int getUserphone() {
		return userphone;
	}
	public void setUserphone(int userphone) {
		this.userphone = userphone;
	}
	public String getUserfirstname() {
		return userfirstname;
	}
	public void setUserfirstname(String userfirstname) {
		this.userfirstname = userfirstname;
	}
	public String getUserlastname() {
		return userlastname;
	}
	public void setUserlastname(String userlastname) {
		this.userlastname = userlastname;
	}
	public int getUsercin() {
		return usercin;
	}
	public void setUsercin(int usercin) {
		this.usercin = usercin;
	}
	public Grade getEmployeegrade() {
		return employeegrade;
	}
	public void setEmployeegrade(Grade employeegrade) {
		this.employeegrade = employeegrade;
	}
	public Date getUserbirthday() {
		return userbirthday;
	}
	public void setUserbirthday(Date userbirthday) {
		this.userbirthday = userbirthday;
	}
	public Role getUserrole() {
		return userrole;
	}
	public void setUserrole(Role userrole) {
		this.userrole = userrole;
	}
	public List<Claim> getUser_claims() {
		return user_claims;
	}
	public void setUser_claims(List<Claim> user_claims) {
		this.user_claims = user_claims;
	}
	public List<Account> getUser_accounts() {
		return user_accounts;
	}
	public void setUser_accounts(List<Account> user_accounts) {
		this.user_accounts = user_accounts;
	}
	public List<Project> getUser_projects() {
		return user_projects;
	}
	public void setUser_projects(List<Project> user_projects) {
		this.user_projects = user_projects;
	}
	
	
}
