package tn.fynova.spring.entities;

import javax.persistence.Enumerated;

public class Employee {
	
	@Enumerated
	private Grade employee_grade;
	

}
