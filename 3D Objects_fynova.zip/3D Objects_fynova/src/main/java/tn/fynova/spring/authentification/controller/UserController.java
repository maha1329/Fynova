package tn.fynova.spring.authentification.controller;

import java.io.BufferedOutputStream;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import tn.fynova.spring.entities.User;
import tn.fynova.spring.entities.SignUpForm;
import tn.fynova.spring.entities.HistoryUser;
import tn.fynova.spring.entities.ResponseMessage;
import tn.fynova.spring.repository.HistoryUserRepository;
import tn.fynova.spring.repository.UserRepository;
//@RestController
@Scope(value = "session")
@RestController(value = "UserController") // Name of the bean in Spring IoC
@ELBeanName(value = "UserController") // Name of the bean used by JSF
@Join(path = "/", to = "/Crud.jsf")
public class UserController {
	
    private final Logger log= LoggerFactory.getLogger(UserController.class);
	private final String sfm = System.getProperty("user.dir") + "/sfm";

    @Autowired
    private  UserRepository userRepository;
    @Autowired
    private HistoryUserRepository historyRepository;
	

	@Autowired
	private PasswordEncoder encoder;

    public UserController(UserRepository repository) {
        this.userRepository = repository;
    }
    
    @RolesAllowed("Employee")
    @GetMapping("/users")
    public Iterable<User> getAllUsers(){
        return userRepository.findAll();
    }
    
    @PostMapping("/newUser")
    
	public ResponseEntity<?> registerUser(@RequestBody SignUpForm signUpRequest) {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Username is already taken!"),
					HttpStatus.BAD_REQUEST);
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Email is already in use!"),
					HttpStatus.BAD_REQUEST);
		}

		// Creating user's account
	//	User user = new User(signUpRequest.getUserfirstname(), signUpRequest.getUsername() , signUpRequest.getUserlastname(),signUpRequest.getEmail(),
		//		encoder.encode(signUpRequest.getUserpassword()), signUpRequest.getUserphone(), signUpRequest.getUserbirthday(), signUpRequest.getUsercin(),signUpRequest.getUserrole(),signUpRequest.getAssociation_customersNumber(),signUpRequest.getAssociation_description(),signUpRequest.getAssociation_fiscalNumber(),signUpRequest.getAssociation_fondationDate(),signUpRequest.getAssociation_name(),signUpRequest.getCustomer_origin(),signUpRequest.getEmployeegrade(),signUpRequest.getJob());
User user=new User(encoder.encode(signUpRequest.getPassword()),
		signUpRequest.getEmail(),
		signUpRequest.getUserphone(),
		signUpRequest.getUsername(),
		signUpRequest.getUserfirstname(),
		signUpRequest.getUserlastname(),
		signUpRequest.getUsercin(),
		signUpRequest.getEmployeegrade(),
		signUpRequest.getUserbirthday(),
		signUpRequest.getUserrole(),
		signUpRequest.getJob(),
		signUpRequest.getCustomer_origin(),
		signUpRequest.getAssociation_fiscalNumber(),
		signUpRequest.getAssociation_name(),
		signUpRequest.getAssociation_description(),
		signUpRequest.getAssociation_fondationDate(),
		signUpRequest.getAssociation_customersNumber(),
		signUpRequest.isAssurance_vie(),
		//signUpRequest.getUser_claims(),
		//signUpRequest.getUser_accounts(),
		//signUpRequest.getUser_projects(),
		signUpRequest.getUserid());
				userRepository.save(user);
				//enregistrer dans l'historique
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				   LocalDateTime now = LocalDateTime.now();  
				HistoryUser his =new HistoryUser(user.getUserid(),now,0 );
				
				historyRepository.save(his);

		return new ResponseEntity<>(new ResponseMessage("User registered successfully!"), HttpStatus.OK);
	}
    @RolesAllowed("Employee")
    @DeleteMapping("/removeUser/{id}")
   
    public ResponseEntity<User> deleteuser(@PathVariable("id") int id)
    {
        log.info("Request for removing user {}", id);
        userRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }
    @RolesAllowed("Employee")
    @PutMapping("/updateUser/{id}")
    
    public  ResponseEntity<User> updateUser( @RequestBody User user, @PathVariable("id")  int id)
    {
        log.info("Request for updating new user {}", user);

        Optional<User> userOptional = userRepository.findById(id);

        if (!userOptional.isPresent())
            return ResponseEntity.notFound().build();

        User user1=userOptional.get();
        user1.setUserid(id);
        user1.setUserfirstname(user.getUserfirstname());
        user1.setUsername(user.getUsername());
        user1.setPassword(user.getPassword());
        user1.setEmail(user.getEmail());
        user1.setUserlastname(user.getUserlastname());
        user1.setAssociation_customersNumber(user.getAssociation_customersNumber());
        user1.setAssociation_description(user.getAssociation_description());
        user1.setAssociation_fiscalNumber(user.getAssociation_fiscalNumber());
        user1.setAssociation_fondationDate(user.getAssociation_fondationDate());
        user1.setAssociation_name(user.getAssociation_name());
        user1.setCustomer_origin(user.getCustomer_origin());
        user1.setEmployeegrade(user.getEmployeegrade());
        user1.setJob(user.getJob());
       // user1.setUser_accounts(user.getUser_accounts());
       // user1.setUser_claims(user.getUser_claims());
       // user1.setUser_projects(user.getUser_projects());
        user1.setUserbirthday(user.getUserbirthday());
        user1.setUsercin(user.getUsercin());
        user1.setUserphone(user.getUserphone());
        user1.setUserrole(user.getUserrole());
        
        User result=userRepository.save(user1);
        return ResponseEntity.ok().body(result);
    }
    @RolesAllowed("Employee")
    @GetMapping("/getUser/{id}")
    
    public ResponseEntity<User> getUser(@PathVariable("id") int id)
    {
        Optional<User> user=userRepository.findById(id);
        return user.map(response -> ResponseEntity.ok().body(response)).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
    
    @GetMapping("/getUserByUsername/{username}")
   
    public ResponseEntity<User> getUserByUsername(@PathVariable("username") String username)
    {
        Optional<User> user=userRepository.findByUsername(username);
        return user.map(response -> ResponseEntity.ok().body(response)).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

}
