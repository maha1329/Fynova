package tn.fynova.spring.service;

public interface IClassification {

	String ClassifierUser(String username);

}
