package tn.fynova.spring.entities;


public class LoginForm {
	
   
    public LoginForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String username;

   
    private String userpassword;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return userpassword;
    }

    public void setPassword(String password) {
        this.userpassword = password;
    }

	public LoginForm(String username, String userpassword) {
		super();
		this.username = username;
		this.userpassword = userpassword;
	}
    
}
