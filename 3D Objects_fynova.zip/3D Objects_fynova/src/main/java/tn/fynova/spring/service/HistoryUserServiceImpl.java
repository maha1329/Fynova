package tn.fynova.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;


import tn.fynova.spring.entities.HistoryUser;

import tn.fynova.spring.repository.HistoryUserRepository;

public class HistoryUserServiceImpl implements IhistoryUserService {
	@Autowired 
	HistoryUserRepository historyUserRepository;
	
	@Override
	public HistoryUser addHistoryUser(HistoryUser e) {
		HistoryUser history = historyUserRepository.save(e);
		return history;
	}

	@Override
	public void deleteHistoryUser(int id) {
		historyUserRepository.deleteById(id);
	}

	@Override
	public List<HistoryUser> retrieveAllHistory() {
		List<HistoryUser> histories = (List<HistoryUser>) historyUserRepository.findAll();
		return histories;
	}

	@Override
	public Optional<HistoryUser> retrieveHistory(int id) {
		Optional<HistoryUser> history = historyUserRepository.findById(id);
		return history;
	}
	
	@Override
	public int CountUserLogIn(int id,String s) {
		int a = historyUserRepository.CountUserLogIn(id);
		return a;
	}
}
